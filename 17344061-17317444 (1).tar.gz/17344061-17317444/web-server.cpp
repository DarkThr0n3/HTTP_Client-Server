#include <string>
#include <thread>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>

#include <sstream>

//3responses
//HTTP/1.0 400 Bad Request
//HTTP/1.0 404 Not Found 
//HTTP/1.0 200 Ok

int port = 4000;
#define FileNameSize 4000
#define BufferSize 1024
bool solve_buffer(char* buffer,char* filename)
{
  printf("%s\n",buffer);
  int l = strlen(buffer);
  int state = 0;
  int i;int pos = 0;
  int gg = 0;
  int tt = 0;
  for(i = 0;i < l;i ++)
  {
 
	if(buffer[i] == ' ' || buffer[i] == 9)
	{
		
	}
	else if(buffer[i] == 'G' && buffer[i + 1] == 'E' && buffer[i + 2] == 'T' && state == 0)
	{
		i = i + 2;state = 1;
		if(gg != 0)return false;
	}
	else if(buffer[i] == '/' && state == 1)
	{
		while(buffer[i] == '/')i ++;
		i --;
		state = 2;
	}
	else if(state == 2)
	{
		while((buffer[i] == ' ' || buffer[i] == 9))i ++;
		while((buffer[i] != ' ' && buffer[i] != 9 && buffer[i] != '\n' && buffer[i] != '\r'))
			{
				filename[pos++] = buffer[i];i ++;
			}//return true;
		tt = 1;
		break;
	}
	
	if(buffer[i] != ' ' && buffer[i] != 9) gg =1;
 
}	
  if(tt == 0)
  return false;
  while(buffer[i] == ' ' || buffer[i] == 9)i ++;
  if(buffer[i] != 'H' ||buffer[i+1] != 'T'|| buffer[i+2] != 'T'|| buffer[i+3] != 'P'|| buffer[i+4] != '/' ||buffer[i+5] != '1' || buffer[i+6] != '.')return false;
  i = i + 8;
  return true;
    
}
int main(int argc,char *argv[])
{
	char initialfilepos[3000];
	bzero(initialfilepos,sizeof(initialfilepos));
  std::cerr << "web server is not implemented yet" << std::endl;
	if(argc == 4)
	{
		printf("argc:%d\n",argc);
		int maxx = 0;
		for(int i = 0;i < strlen(argv[2]);i ++)
		{
			maxx *= 10;
			maxx += (argv[2][i] - '0');
		}
		port = maxx;

		for(int i = 0;i < strlen(argv[3]);i ++)
		{
			initialfilepos[i] = argv[3][i];
		}
		if(initialfilepos[strlen(initialfilepos)-1] != '/')
		{
			initialfilepos[strlen(initialfilepos)] = '/';
		}
	}
  // do your stuff here! or not if you don't want to.!!!!
  struct sockaddr_in ServerAddr;
  bzero(&ServerAddr,sizeof(ServerAddr));//initialize the server address
  ServerAddr.sin_family = AF_INET;
  ServerAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  ServerAddr.sin_port = htons(port);
  int ServerSocket = socket(AF_INET, SOCK_STREAM, 0);
 
  if (bind(ServerSocket, (struct sockaddr*)&ServerAddr, sizeof(ServerAddr)) == -1)    
    {    
        printf("Server Bind Port: %d Error!\n", port);    
        exit(1);    
    }  

  if (listen(ServerSocket, 5) == -1)
    {
	 printf("Server Listen Error!\n");
        exit(1);
    }   

  printf("Server is ready to run!\n");

  while(1)
	{
		struct sockaddr_in ClientAddr;    
        	socklen_t length = sizeof(ClientAddr);    
      
		int NewServerSocket = accept(ServerSocket, (struct sockaddr*)&ClientAddr, &length);    
        	if (NewServerSocket < 0)    
        	{    
            		printf("Server Accept Error!\n");    
            		break;    
        	}    
		
		//if is father ...
	if(fork()>0)
//	if(0)
		{close(NewServerSocket);}//sleep(20);}
	else
		{
		
		char information[INET_ADDRSTRLEN] = {'\0'};
		 inet_ntop(ClientAddr.sin_family, &ClientAddr.sin_addr, information, sizeof(information));
		printf("Accept a connection from: %s : %d\n", information ,ntohs(ClientAddr.sin_port));
	
		//if(fork() < 0)printf("ERROR\n");
		//if is son ...
		char FileName[FileNameSize + 1];
		bzero(FileName,sizeof(FileName));
		char Buffer[BufferSize];
		bzero(Buffer,sizeof(Buffer));
		recv(NewServerSocket, Buffer, BufferSize, 0);
		
		if(strlen(Buffer) > FileNameSize)
		{
			printf("Too Long File Name!\n");
			exit(1);
		}
	//	printf("%s\n",Buffer);
		
		if(!solve_buffer(Buffer,FileName)){
		  char bb[3000] = "HTTP/1.0 400 Bad Request \r\n\r\n";
		  send(NewServerSocket, bb, strlen(bb), 0);
		  exit(0);
		}
	printf("%s\n",FileName);
		bool ct = 1;
		for(int i = 0;i < FileNameSize;i ++)
		{
			if(FileName[i] == '\n' || FileName[i] == '\r')ct = 0;
			FileName[i] *= ct;
		}
		for(int i = 0;i < strlen(FileName);i ++)
		{
			initialfilepos[strlen(initialfilepos)] = FileName[i];
		}
		
		FILE *fp = fopen(initialfilepos, "r");    
        	if (fp == NULL)//need modify    
        	{    
			char bb[3000] = "HTTP/1.0 404 Not Found \r\n\r\n";
			send(NewServerSocket, bb, strlen(bb), 0);
            		printf("File: %s Not Found!\n", initialfilepos);
			exit(0);    
        	}   
		char bb[3000] = "HTTP/1.0 200 OK \r\n\r\n";
		send(NewServerSocket, bb, strlen(bb), 0);
		//
		bzero(Buffer,sizeof(Buffer));
		int length3 = 0;
		while(1)
		{
			length3 = fread(Buffer, sizeof(char), BufferSize,fp);
			if(length3 <= 0)break;
			if (send(NewServerSocket, Buffer, length3, 0) < 0)    
                	{    
                    		printf("Send File:%s Error!\n", FileName);    
                    		break;    
                	}    	
			//	printf("%s\n______________\n",Buffer);
			bzero(Buffer,sizeof(Buffer));
		}
		fclose(fp);
		//char bb[3000] = "HTTP/1.0 200 OK \r\n";
		//send(NewServerSocket, bb, strlen(bb), 0);
		printf("File %s Transfer Success!\n",FileName);
		close(NewServerSocket);
		break;
		}
	}close(ServerSocket);
	return 0;

}
