#include <string>
#include <thread>
#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>

#include <sstream>
int port = 4000;
char arg[3000];
char request[3000];
char fn[3000];
#define FileNameSize 4000
#define BufferSize 1024
void pre_solve()
{
  request[0] = 'G';
  request[1] = 'E';
  request[2] = 'T';
  request[3] = ' ';
  port = 0;
  bzero(fn,sizeof(fn));
  if(arg[0] != 'h'||arg[1] != 't'||arg[2] != 't'||arg[3] != 'p'||arg[4]!= ':'
	||arg[5] != '/' ){}
  else
	{
		int i = 6;
		while(arg[i] != ':')i ++;
		i ++;port = 0;
		while(arg[i] >= '0' && arg[i] <= '9')
		{
			port *= 10;
			port += (arg[i]-'0');i ++;
		}int gg = 4;
		while(i < strlen(arg))
		{
			request[gg]=arg[i];i ++;gg ++;
		}
		request[gg] = ' ';
		while(request[gg] != '/')gg --;gg ++;int popo = 0;
                while(gg < strlen(request))fn[popo++] = request[gg++];
    request[gg ++] = ' ';
    request[gg ++] = 'H';
    request[gg ++] = 'T';
    request[gg ++] = 'T';
    request[gg ++] = 'P';
    request[gg ++]  = '/';
    request[gg ++] = '1';
    request[gg ++] = '.';
    request[gg ++]  = '0';
    request[gg ++] = '\r';
    request[gg ++] = '\n';
	}
}
int main(int argc,char *argv[])
{
  // do your stuff here! or not if you don't want to.
for(int iii = 1;iii < argc;iii ++)
{
  bzero(arg,sizeof(arg));
  bzero(request,sizeof(request));
  for(int jjj = 0;jjj < strlen(argv[iii]);jjj ++)
	arg[jjj] = argv[iii][jjj];
  pre_solve();
  printf("%d %s %s\n",port,request,fn);
  struct sockaddr_in ClientAddr;
  bzero(&ClientAddr,sizeof(ClientAddr));//initialize the server address
  ClientAddr.sin_family = AF_INET;
  ClientAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  ClientAddr.sin_port = htons(0);
  int ClientSocket = socket(AF_INET, SOCK_STREAM, 0);

  if (bind(ClientSocket, (struct sockaddr*)&ClientAddr, sizeof(ClientAddr)) == -1)
    {
        printf("Client Bind Port Error!\n");
        exit(1);
    }
  struct sockaddr_in ServerAddr;
  bzero(&ServerAddr,sizeof(ServerAddr));//initialize the server address
  ServerAddr.sin_family = AF_INET;
  ServerAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  ServerAddr.sin_port = htons(port);
  socklen_t ServerAddrLength = sizeof(ServerAddr);
  if (connect(ClientSocket, (struct sockaddr*)&ServerAddr, ServerAddrLength) < 0)    
    {    
        printf("Can Not Connect To Server!\n");    
        exit(1);    
    }printf("Client Connected\n");


                //char FileName[FileNameSize + 1] = "spacer.GIF";
                //bzero(FileName,sizeof(FileName));
		//printf("Input File Name\n");
		//scanf("%s",FileName);
		char Buffer[BufferSize];
		bzero(Buffer,sizeof(Buffer));	
                if(strlen(fn) > BufferSize)
                {
                        printf("Too Long File Name!\n");
                        exit(1);
                }
                strncpy(Buffer,request, strlen(request));
          //      char Buffer2[2000] =  "GT /index.html http/1.0";
		send(ClientSocket, Buffer, BufferSize, 0);
	
    //web-client from below open the file from SAME DIRECTORY WHERE IT STARTS	
		FILE *fp;
		
		bzero(Buffer, sizeof(Buffer));
		int l = recv(ClientSocket, Buffer, 20, 0);//buffersize
		
		if(Buffer[9] == '2' && Buffer[10] == '0' && Buffer[11] == '0')
		{
		  
		  fp = fopen(fn, "w+");
		  int ii = 0;
		  printf("buffer:%s\n",Buffer);
		  while(Buffer[ii] != 'K')ii ++;ii ++;ii ++;
		  while(Buffer[ii] == '\r' || Buffer[ii] == '\n')ii ++;
		  char gg[2000];
		  int kk = 0;
		  for(;ii < strlen(Buffer);ii ++)gg[kk ++] = Buffer[ii];
		  
		//  fwrite(gg, sizeof(char), strlen(gg), fp);
		bzero(Buffer, sizeof(Buffer));

		while(1)
		{
			int l = recv(ClientSocket, Buffer, BufferSize, 0);
		 // printf("\nOUTPUT BUFFER\n%s",Buffer);
			if(l == 0)break;
			
			fwrite(Buffer, sizeof(char), l, fp);
			bzero(Buffer,sizeof(Buffer)); 
		}   
		bzero(Buffer,sizeof(Buffer)); 
		  printf("Client Succeed\n");
	//	fclose(fp);    
		}else{printf("%s\n",Buffer);}
		fclose(fp);  
    close(ClientSocket); 
}	
}
